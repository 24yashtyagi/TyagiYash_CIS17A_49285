/* Tyagi
 * Yash - IntroLab - 49285
 */

#include <iostream>

using namespace std;

int main() {

    cout << "Hello World";
    
    return 0;
}

